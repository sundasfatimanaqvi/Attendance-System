import numpy as np
import pickle
from sklearn.preprocessing import LabelEncoder
import os
import cv2
import face_recognition

import numpy as np
import pickle
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC
import os
import cv2
import face_recognition

# Load features and labels
X = []
y = []

training_dir = r'Main\face_recognition_data\training_dataset'
for person_name in os.listdir(training_dir):
    curr_directory = os.path.join(training_dir, person_name)
    if not os.path.isdir(curr_directory):
        continue
    for filename in os.listdir(curr_directory):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            imagefile = os.path.join(curr_directory, filename)
            image = cv2.imread(imagefile)
            try:
                X.append((face_recognition.face_encodings(image)[0]).tolist())
                y.append(person_name)
            except:
                os.remove(imagefile)

# Convert lists to numpy arrays
X1 = np.array(X)
y = np.array(y)

# Print shapes to diagnose the mismatch
print(f"Shape of X1 (features): {X1.shape}")
print(f"Shape of y (labels): {y.shape}")

# Ensure consistency between number of samples in X1 and y
assert len(X1) == len(y), "Mismatch between number of samples in features and labels."

# Encode class names into indices
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
# Load the trained SVC model
svc_save_path = r'Main\face_recognition_data\svc.sav'
with open(svc_save_path, 'rb') as f:
    svc = pickle.load(f)

# Make predictions
predictions = svc.predict(X1)

# Ensure predictions are mapped back to original class names if necessary
predicted_class_names = label_encoder.inverse_transform(predictions)

# Calculate evaluation metrics
accuracy = accuracy_score(y_encoded, predictions)
precision = precision_score(y_encoded, predictions, average='weighted')
recall = recall_score(y_encoded, predictions, average='weighted')
f1 = f1_score(y_encoded, predictions, average='weighted')

print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1-Score:", f1)
